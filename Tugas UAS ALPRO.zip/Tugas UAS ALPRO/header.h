#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

int temp,i,j;
int x, y;
int pilih;
int cari;
int squentialSearch(int harga1[],int uk, int cari);
void swap(int data[], int i, int j);
void selectionSort1(int data[], int i, int n);
void selectionSort2(int data[], int i, int n);
void cetak(int *arrData, int ukuran);

#endif // HEADER_H_INCLUDED
